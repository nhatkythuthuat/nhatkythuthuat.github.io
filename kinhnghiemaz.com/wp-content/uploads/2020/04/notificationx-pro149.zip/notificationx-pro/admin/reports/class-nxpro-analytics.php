<?php 
/**
 * This class is responsible for making stats for each NotificationX
 * 
 * @since 1.0.2
 */
class NotificationXPro_Analytics {
    /**
     * Get a single Instance of Analytics
     * @var NotificationXPro_Analytics
     */
    private static $_instance = null;
    /**
     * List of NotificationX
     * @var arrau
     */
    private static $notificationx = array();
    /**
     * Colors for Bar
     */
    private $colors = array(
        '#1abc9c',
        '#27ae60',
        '#3498db',
        '#8e44ad',
        '#e67e22',
        '#e74c3c',
        '#f39c12',
        '#34495e',
        '#9b59b6',
        '#16a085'
    );

    private $nx_reporting = null;

    public function __construct() {
        add_action( 'admin_init', array( $this, 'notificationx' ) );
        add_action( 'notificationx_after_analytics_header', array( $this, 'analytics_display_pro' ), 12 );
        add_action( 'wp_ajax_nx_analytics_calc', array( $this, 'analytics_calc' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueues' ) );       
        add_filter( 'nx_email_analytics_reporting_sections', array( $this, 'reporting_settings' ) );
        $this->nx_reporting = NotificationX_Report_Email::get_instance();
        if( isset( $this->nx_reporting->settings['disable_reporting'] ) && ! $this->nx_reporting->settings['disable_reporting'] ) {
            add_action('admin_init', array( $this, 'set_reporting_event' ));
            add_action('monthly_email_reporting', array( $this, 'send_email_monthly' ));
            add_action('daily_email_reporting', array( $this, 'send_email_daily' ));
        }
    }


    public function send_email_monthly(){
        return $this->nx_reporting->send_email_weekly( 'nx_monthly' );
    }
    public function send_email_daily(){
        return $this->nx_reporting->send_email_weekly( 'nx_daily' );
    }

    public function reporting_settings( $options ){
        unset( $options['email_reporting']['fields']['reporting_frequency']['disable'] );
        unset( $options['email_reporting']['fields']['reporting_subject']['disable'] );
        return $options;
    }

    public function set_reporting_event(){
        if( isset( $this->nx_reporting->settings['enable_analytics'] ) && ! $this->nx_reporting->settings['enable_analytics'] ) {
            return;
        }

        if( $this->nx_reporting->reporting_frequency() === 'nx_daily' ) {
            $datetime = strtotime( "+1days 9AM" );
            $this->nx_reporting->mail_report_deactivation( 'weekly_email_reporting' );
            $this->nx_reporting->mail_report_deactivation( 'monthly_email_reporting' );
            if ( ! wp_next_scheduled ( 'daily_email_reporting' ) ) {
                wp_schedule_event( $datetime, $this->nx_reporting->reporting_frequency(), 'daily_email_reporting' );
            }
        }
        if( $this->nx_reporting->reporting_frequency() === 'nx_monthly' ) {
            $datetime = strtotime( "first day of next month 9AM" );
            $this->nx_reporting->mail_report_deactivation( 'daily_email_reporting' );
            $this->nx_reporting->mail_report_deactivation( 'weekly_email_reporting' );
            if ( ! wp_next_scheduled ( 'monthly_email_reporting' ) ) {
                wp_schedule_event( $datetime, $this->nx_reporting->reporting_frequency(), 'monthly_email_reporting' );
            }
        }
    }

    /**
     * Get || Making a Single Instance of Analytics
     * @return self
     */
    public static function get_instance(){
        if( self::$_instance === null ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    public static function notificationx(){
        $notificationx = new WP_Query(array(
            'post_type'      => 'notificationx',
            'posts_per_page' => -1,
        ));

        return self::$notificationx = $notificationx->posts;
    }
    /**
     * This method is responsible for adding analytics Pro table in frontend.
     * @return void
     */
    public function analytics_display_pro(){   
            
        $comparison_factor_list = array(
            'views' => 'Views',
            'clicks' => 'Clicks',
            'ctr' => 'CTR',
        );

        if( file_exists( NOTIFICATIONX_PRO_ROOT_DIR_PATH . 'admin/reports/nxpro-admin-analytics-display.php' ) ) {
            return include_once NOTIFICATIONX_PRO_ROOT_DIR_PATH . 'admin/reports/nxpro-admin-analytics-display.php';
        }
    }

    private function random_color_part() {
        return str_pad( dechex( mt_rand( 0, 255 ) ), 2, '0', STR_PAD_LEFT);
    }
    
    private function random_color( $index = '' ) {
        if( ! empty( $index ) ) {
            if( isset( $this->colors[ $index ] ) ) {
                return $this->colors[ $index ];
            } else {
                return '#' . $this->random_color_part() . $this->random_color_part() . $this->random_color_part();
            }
        }
    }

    protected function labels( $query_vars = array() ){
        $current_date = date('d-m-Y', current_time('timestamp'));
        $start_date = date('d-m-Y', strtotime( $current_date . ' -7days' ));
        if( isset( $query_vars['start_date'] ) && ! empty( $query_vars['start_date'] ) ) {
            $start_date = $query_vars['start_date'];
        }

        if( isset( $query_vars['end_date'] ) && ! empty( $query_vars['end_date'] ) ) {
            $current_date = $query_vars['end_date'];
        }

        $dates = array();
        $start_date_diff = new DateTime( $start_date );
        $current_date_diff = new DateTime( $current_date );
        $diff = $current_date_diff->diff($start_date_diff);
        $counter = isset( $diff->days ) ? $diff->days : 0;
        for( $i = 0; $i <= $counter; $i++ ) {
            $date = $i === 0 ? $start_date : $start_date . " +$i days";
            $dates[] = date( 'M d', strtotime( $date ) );
        }

        $this->dates = $dates;

        return $dates;
    }

    protected function datasets( $query_vars = array() ){
        global $wpdb;

        $ids = false;
        $extra_sql_input = $extra_sql = '';
        if( ! isset( $query_vars['notificationx'] ) ) {
            $ids = true;
        }


        if( isset( $query_vars['notificationx'] ) ) {
            $notificationx = trim($query_vars['notificationx']);
            if( strpos( $notificationx, 'all' ) === false ) {
                $ids = false;
            } else {
                $ids = true;
            }
        }


        if( ! $ids ) {
            $extra_sql_input = $notificationx;
            $extra_sql = "AND POSTS.ID IN ( $extra_sql_input )";
        }

        $inner_sql = "SELECT DISTINCT INNER_POSTS.ID, INNER_POSTS.post_title FROM $wpdb->posts AS INNER_POSTS INNER JOIN $wpdb->postmeta AS INNER_META ON INNER_POSTS.ID = INNER_META.post_id WHERE INNER_POSTS.post_type = '%s'";

        $query = $wpdb->prepare(
            "SELECT POSTS.ID, POSTS.post_title, META.meta_value FROM ( $inner_sql ) as POSTS INNER JOIN $wpdb->postmeta as META ON POSTS.ID = META.post_id WHERE META.meta_key = %s $extra_sql", 
            array(
                'notificationx',
                '_nx_meta_impression_per_day'
            )
        );
        $results = $wpdb->get_results( $query );

        $default_value = array(
            "fill" => false,
        );

        $datasets = $views = $data = $impressions = $comaprison_factor = $available_data = array();
        $impressions = $clicks = $ctr = array_fill_keys( $this->dates, 0 );

        if( isset( $query_vars['comparison_factor'] ) && ! empty( $query_vars['comparison_factor'] ) && $query_vars['comparison_factor'] != null ) {
            if( strpos( $query_vars['comparison_factor'], ',' ) !== false && strpos( $query_vars['comparison_factor'], ',' ) >= 0 ) {
                $comaprison_factor = explode( ',', $query_vars['comparison_factor'] );
            } else {
                if( $query_vars['comparison_factor'] != 'undefined' ) {
                    $comaprison_factor = [ $query_vars['comparison_factor'] ];
                }
            }
        }

        if( empty( $comaprison_factor ) ) {
            $comaprison_factor = array( 'views' );
        }
        $number_of_impressions = $number_of_clicks = $max_stepped_size = 0;

        if( ! empty( $results ) ) {
            $index = 0;

            foreach( $results as $value ) {
                $unserialize = unserialize( $value->meta_value );
                if( ! empty( $unserialize ) ) {
                    foreach( $unserialize as $date => $single ) {
                        $temp_date = date('M d', strtotime( $date ));
                        if( isset( $impressions[ $temp_date ] ) ) {
                            $impressions[ $temp_date ] = $number_of_impressions = isset( $single['impressions'] ) ? $single['impressions'] : 0;
                        }
                        if( in_array( 'views', $comaprison_factor ) ) {
                            $available_data[ 'views' ] = $impressions;
                            if( $max_stepped_size < $number_of_impressions ) {
                                $max_stepped_size = $number_of_impressions;
                            }
                        }
                        if( isset( $clicks[ $temp_date ] ) ) {
                            $clicks[ $temp_date ] = $number_of_clicks = isset( $single['clicks'] ) ? $single['clicks'] : 0;
                        }
                        if( in_array( 'clicks', $comaprison_factor ) ) { 
                            $available_data[ 'clicks' ] = $clicks;
                            if( $max_stepped_size < $number_of_clicks ) {
                                $max_stepped_size = $number_of_clicks;
                            }
                        }
                        if( in_array( 'ctr', $comaprison_factor ) ) { 
                            $ctr[ $temp_date ] = $number_of_ctr = $number_of_impressions > 0 ? number_format( ( intval( $number_of_clicks ) / intval( $number_of_impressions ) ) * 100, 2) : 0;
                            $available_data[ 'ctr' ] = $ctr;
                            if( $max_stepped_size < $number_of_ctr ) {
                                $max_stepped_size = $number_of_ctr;
                            }
                        }

                        $number_of_impressions = $number_of_clicks = 0;
                    }
                    //TODO: has to check again and again.
                    if( $available_data ) {
                        foreach( $available_data as $factor => $factor_data ){
                            $data['data'] = array_values( $factor_data );
                            $data = array_merge( $default_value, $data );
                            $color = $this->random_color( ++$index );
                            $data['backgroundColor'] = $color;
                            $data['borderColor'] = $color;
                            $factor_label = $factor == 'ctr' ? 'CTR' : ucwords( $factor );
                            $data['label'] = $value->post_title . ' - ' . $factor_label;
                            $data['labelString'] = 'Impressions';

                            $views[ $value->ID . '_' . $factor ] = $data;
                            $views[ 'stepped_size' ] = $max_stepped_size;
                        }
                    }
                }
            }

            return $views;
        }
        return array();
    }

    public function enqueues( $hook ) {
        if( $hook !== 'notificationx_page_nx-analytics' ) {
            return;
        }
        wp_enqueue_style(
			'notificationx-select2', 
			NOTIFICATIONX_ADMIN_URL . 'assets/css/select2.min.css', 
			array(), '1.0.1', 'all' 
		);
        wp_enqueue_style( 
			'notificationx-chart', 
			NOTIFICATIONX_ADMIN_URL . 'assets/css/Chart.css', 
			array(), '1.0.1', 'all' 
        );
        wp_enqueue_script( 'jquery-ui-datepicker' );
        wp_enqueue_script( 
			'notificationx-select2', 
			NOTIFICATIONX_ADMIN_URL . 'assets/js/select2.min.js', 
			array( 'jquery' ), '1.0.1', true 
		);
		wp_enqueue_script( 
			'chartjs', 
			NOTIFICATIONX_ADMIN_URL . 'assets/js/Chart.min.js', 
			array( 'jquery' ), '1.0.1', true 
		);
		wp_enqueue_script( 
			'notificationx-analytics', 
			NOTIFICATIONX_ADMIN_URL . 'assets/js/nx-analytics.js', 
			array( 'jquery', 'jquery-ui-datepicker', 'chartjs' ), '1.0.1', true 
        );
    }

    public function analytics_calc(){
        if ( empty( $_POST ) || ! check_admin_referer( '_nx_analytics_nonce', 'nonce' ) ) {
            return;
        }
        if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], '_nx_analytics_nonce' ) ) {
            return;
        }

        $dates = $this->labels( $_POST['query_vars'] );
        $datasets = $this->datasets( $_POST['query_vars'] );

        echo json_encode( array(
            'labels'   => $dates,
            'datasets' => $datasets,
        ));

        wp_die();
    }
}

NotificationXPro_Analytics::get_instance();